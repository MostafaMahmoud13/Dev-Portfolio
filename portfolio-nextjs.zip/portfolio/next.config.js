/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  // For GitHub Pages deployment:
  // basePath: '/your-repo-name',
  // output: 'export',
  images: {
    unoptimized: true,
  },
}

module.exports = nextConfig
