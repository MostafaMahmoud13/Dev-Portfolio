export const siteData = {
  name: "Your Name",
  role: "Full-Stack Developer & Media Buyer",
  email: "hello@yourname.dev",
  github: "https://github.com/yourname",
  linkedin: "https://linkedin.com/in/yourname",
  twitter: "https://twitter.com/yourname",
  bio: [
    "I'm a Full-Stack Developer and Media Buyer with a passion for building high-performance web applications and data-driven marketing campaigns. I bridge the gap between technical engineering and growth-focused strategy.",
    "From pixel-perfect UIs to server-side architectures, I architect solutions that are fast, scalable, and built to last. On the media side, I've managed six-figure ad spends across Meta, Google, and TikTok — turning data into growth.",
  ],
}

export const skills = [
  { name: "HTML / CSS", level: 95 },
  { name: "JavaScript", level: 90 },
  { name: "React", level: 88 },
  { name: "Node.js", level: 82 },
  { name: "Media Buying", level: 92 },
  { name: "Marketing", level: 87 },
]

export const stats = [
  { value: 50, suffix: "+", label: "Projects Completed" },
  { value: 5, suffix: "+", label: "Years Experience" },
  { value: 30, suffix: "+", label: "Clients Served" },
  { value: 8, suffix: "x", label: "Avg. ROAS Achieved" },
]

export const projects = [
  {
    id: "001",
    title: "E-Commerce Platform",
    description: "Full-featured online store with real-time inventory, payment processing, and AI-powered product recommendations. 300% conversion uplift.",
    tags: ["React", "Node.js", "MongoDB", "Stripe"],
    emoji: "🛒",
    color: "#00d4ff",
    demo: "#",
    github: "#",
  },
  {
    id: "002",
    title: "Ad Analytics Dashboard",
    description: "Real-time cross-platform ad performance dashboard integrating Meta, Google & TikTok APIs. Custom ROAS tracking and automated alerts.",
    tags: ["React", "D3.js", "Python", "Meta API"],
    emoji: "📊",
    color: "#7b2fff",
    demo: "#",
    github: "#",
  },
  {
    id: "003",
    title: "AI SaaS Platform",
    description: "Subscription-based SaaS with AI content generation, team collaboration, and usage-based billing. Scaled to 10K+ monthly active users.",
    tags: ["Next.js", "OpenAI", "PostgreSQL", "Vercel"],
    emoji: "🤖",
    color: "#0066ff",
    demo: "#",
    github: "#",
  },
  {
    id: "004",
    title: "Mobile Delivery App",
    description: "Real-time delivery tracking app with driver routing optimization, customer notifications, and live map integration. 4.9★ App Store rating.",
    tags: ["React Native", "Node.js", "Socket.io", "Maps API"],
    emoji: "📱",
    color: "#ff6b00",
    demo: "#",
    github: "#",
  },
  {
    id: "005",
    title: "LMS & Course Platform",
    description: "Full learning management system with video courses, quizzes, certificates, and integrated payment gateway. 50K+ enrolled students.",
    tags: ["Next.js", "Prisma", "AWS S3", "Stripe"],
    emoji: "🎓",
    color: "#00ff9d",
    demo: "#",
    github: "#",
  },
  {
    id: "006",
    title: "Growth Funnel System",
    description: "Automated marketing funnel with A/B testing, behavioral triggers, email sequences, and attribution modeling. 8x ROAS achieved.",
    tags: ["JavaScript", "HubSpot", "Klaviyo", "Segment"],
    emoji: "📈",
    color: "#00d4ff",
    demo: "#",
    github: "#",
  },
]
