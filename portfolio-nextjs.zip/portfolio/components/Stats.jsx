import { useRef, useEffect, useState } from 'react'
import { motion, useInView } from 'framer-motion'
import { stats } from '../data/portfolio'

function useCounter(target, isActive) {
  const [value, setValue] = useState(0)
  useEffect(() => {
    if (!isActive) return
    let current = 0
    const step = target / 60
    const timer = setInterval(() => {
      current = Math.min(current + step, target)
      setValue(Math.round(current))
      if (current >= target) clearInterval(timer)
    }, 20)
    return () => clearInterval(timer)
  }, [isActive, target])
  return value
}

function StatItem({ stat, delay, inView }) {
  const count = useCounter(stat.value, inView)
  const [hovered, setHovered] = useState(false)

  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      animate={inView ? { opacity: 1, y: 0 } : {}}
      transition={{ duration: 0.8, delay, ease: [0.22, 1, 0.36, 1] }}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      style={{
        background: hovered ? 'var(--surface2)' : 'var(--surface)',
        padding: '60px 40px', textAlign: 'center', position: 'relative', overflow: 'hidden',
        transition: 'background 0.3s', cursor: 'none',
      }}
    >
      {hovered && (
        <div style={{
          position: 'absolute', top: 0, left: '50%', transform: 'translateX(-50%)',
          width: '60%', height: 2,
          background: 'linear-gradient(90deg, transparent, var(--neon), transparent)',
        }} />
      )}
      <div style={{
        fontFamily: "'Syne', sans-serif", fontSize: '4rem', fontWeight: 800,
        background: 'linear-gradient(135deg, var(--neon), var(--neon2))',
        WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent',
        backgroundClip: 'text', lineHeight: 1, marginBottom: 8,
      }}>
        {count}{stat.suffix}
      </div>
      <div style={{
        fontFamily: "'DM Mono', monospace", fontSize: '0.72rem', color: 'var(--muted)',
        letterSpacing: '0.12em', textTransform: 'uppercase',
      }}>
        {stat.label}
      </div>
    </motion.div>
  )
}

export default function Stats() {
  const ref = useRef(null)
  const inView = useInView(ref, { once: true, margin: '-80px' })

  return (
    <section id="stats" ref={ref} style={{ padding: '80px 6%', position: 'relative', zIndex: 1 }}>
      <div style={{
        display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 1,
        background: 'var(--border)', border: '1px solid var(--border)', overflow: 'hidden',
      }}
        className="stats-grid"
      >
        {stats.map((stat, i) => (
          <StatItem key={stat.label} stat={stat} delay={i * 0.1} inView={inView} />
        ))}
      </div>
      <style>{`
        @media(max-width:768px) { .stats-grid { grid-template-columns: repeat(2, 1fr) !important; } }
        @media(max-width:400px) { .stats-grid { grid-template-columns: 1fr 1fr !important; } }
      `}</style>
    </section>
  )
}
