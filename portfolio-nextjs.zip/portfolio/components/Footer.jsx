import { siteData } from '../data/portfolio'

const socials = [
  { icon: '⌥', label: 'GitHub', href: siteData.github },
  { icon: 'in', label: 'LinkedIn', href: siteData.linkedin },
  { icon: '✉', label: 'Email', href: `mailto:${siteData.email}` },
  { icon: '𝕏', label: 'Twitter', href: siteData.twitter },
]

export default function Footer() {
  return (
    <footer style={{
      padding: '40px 6%',
      borderTop: '1px solid var(--border)',
      display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      position: 'relative', zIndex: 1, flexWrap: 'wrap', gap: 20,
    }}>
      <div style={{
        fontFamily: "'DM Mono', monospace", fontSize: '0.72rem',
        color: 'var(--muted)', letterSpacing: '0.06em',
      }}>
        &copy; {new Date().getFullYear()}{' '}
        <span style={{ color: 'var(--neon)' }}>{siteData.name}.dev</span>{' '}
        — Built with ❤️ &amp; ☕
      </div>

      <div style={{ display: 'flex', gap: 12 }}>
        {socials.map(s => (
          <a
            key={s.label}
            href={s.href}
            title={s.label}
            target="_blank"
            rel="noopener noreferrer"
            style={{
              width: 40, height: 40,
              border: '1px solid var(--border)',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              textDecoration: 'none', fontSize: '1rem', color: 'var(--muted)',
              transition: 'all 0.3s', cursor: 'none',
              clipPath: 'polygon(6px 0%, 100% 0%, calc(100% - 6px) 100%, 0% 100%)',
            }}
            onMouseEnter={e => {
              e.currentTarget.style.borderColor = 'var(--neon)'
              e.currentTarget.style.color = 'var(--neon)'
              e.currentTarget.style.boxShadow = '0 0 40px rgba(0,212,255,0.25)'
              e.currentTarget.style.background = 'rgba(0,212,255,0.06)'
            }}
            onMouseLeave={e => {
              e.currentTarget.style.borderColor = 'var(--border)'
              e.currentTarget.style.color = 'var(--muted)'
              e.currentTarget.style.boxShadow = 'none'
              e.currentTarget.style.background = 'transparent'
            }}
          >
            {s.icon}
          </a>
        ))}
      </div>
    </footer>
  )
}
