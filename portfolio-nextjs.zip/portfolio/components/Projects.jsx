import { useRef, useState } from 'react'
import { motion, useInView } from 'framer-motion'
import { projects } from '../data/portfolio'

const fadeUp = {
  hidden: { opacity: 0, y: 40 },
  visible: (i) => ({
    opacity: 1, y: 0,
    transition: { duration: 0.8, delay: i * 0.1, ease: [0.22, 1, 0.36, 1] },
  }),
}

export default function Projects() {
  const ref = useRef(null)
  const inView = useInView(ref, { once: true, margin: '-80px' })

  return (
    <section id="projects" ref={ref} style={{ padding: '120px 6%', position: 'relative', zIndex: 1 }}>
      <motion.div
        variants={fadeUp} custom={0} initial="hidden" animate={inView ? 'visible' : 'hidden'}
        className="section-label"
      >
        02 — Projects
      </motion.div>

      <motion.h2
        variants={fadeUp} custom={1} initial="hidden" animate={inView ? 'visible' : 'hidden'}
        style={{
          fontFamily: "'Syne', sans-serif", fontSize: 'clamp(2.5rem, 5vw, 4rem)',
          fontWeight: 800, letterSpacing: '-0.03em', lineHeight: 1, marginBottom: '3rem',
        }}
      >
        Selected{' '}
        <span style={{
          background: 'linear-gradient(90deg, #00d4ff, #0066ff, #7b2fff)',
          WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', backgroundClip: 'text',
        }}>Work</span>
      </motion.h2>

      <div style={{
        display: 'grid',
        gridTemplateColumns: 'repeat(auto-fill, minmax(340px, 1fr))',
        gap: 24,
      }}>
        {projects.map((project, i) => (
          <motion.div
            key={project.id}
            variants={fadeUp} custom={i + 2} initial="hidden" animate={inView ? 'visible' : 'hidden'}
          >
            <ProjectCard project={project} />
          </motion.div>
        ))}
      </div>
    </section>
  )
}

function ProjectCard({ project }) {
  const [tilt, setTilt] = useState({ x: 0, y: 0 })
  const [mousePos, setMousePos] = useState({ x: 50, y: 50 })
  const [hovered, setHovered] = useState(false)
  const cardRef = useRef(null)

  const handleMouseMove = (e) => {
    const r = cardRef.current.getBoundingClientRect()
    const x = (e.clientX - r.left) / r.width - 0.5
    const y = (e.clientY - r.top) / r.height - 0.5
    setTilt({ x: x * 10, y: -y * 8 })
    setMousePos({ x: ((e.clientX - r.left) / r.width) * 100, y: ((e.clientY - r.top) / r.height) * 100 })
  }

  const handleMouseLeave = () => {
    setTilt({ x: 0, y: 0 })
    setHovered(false)
  }

  return (
    <motion.div
      ref={cardRef}
      onMouseMove={handleMouseMove}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={handleMouseLeave}
      animate={{
        rotateX: tilt.y,
        rotateY: tilt.x,
        y: hovered ? -8 : 0,
      }}
      transition={{ type: 'spring', stiffness: 300, damping: 30 }}
      style={{
        background: 'var(--surface)',
        border: `1px solid ${hovered ? 'rgba(0,212,255,0.4)' : 'var(--border)'}`,
        overflow: 'hidden', position: 'relative',
        transformStyle: 'preserve-3d', cursor: 'none',
        boxShadow: hovered ? '0 20px 60px rgba(0,0,0,0.5), 0 0 40px rgba(0,212,255,0.25)' : 'none',
        transition: 'border-color 0.3s, box-shadow 0.4s',
      }}
    >
      {/* Glow spotlight */}
      {hovered && (
        <div style={{
          position: 'absolute', inset: 0, pointerEvents: 'none',
          background: `radial-gradient(circle at ${mousePos.x}% ${mousePos.y}%, rgba(0,212,255,0.08), transparent 60%)`,
          zIndex: 1,
        }} />
      )}

      {/* Preview */}
      <div style={{
        width: '100%', height: 200, overflow: 'hidden', position: 'relative',
        background: 'linear-gradient(135deg, var(--surface2), var(--bg2))',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
      }}>
        <div style={{
          position: 'absolute', width: 150, height: 150, borderRadius: '50%',
          background: project.color, filter: 'blur(50px)', opacity: 0.25,
          top: '30%', left: '30%',
        }} />
        <span style={{ fontSize: '3.5rem', position: 'relative', zIndex: 1 }}>{project.emoji}</span>
        <div style={{
          position: 'absolute', inset: 0,
          background: 'linear-gradient(to bottom, transparent 50%, var(--surface) 100%)',
        }} />
      </div>

      {/* Body */}
      <div style={{ padding: 24, position: 'relative', zIndex: 2 }}>
        <div style={{
          fontFamily: "'DM Mono', monospace", fontSize: '0.65rem', color: 'var(--neon)',
          letterSpacing: '0.15em', textTransform: 'uppercase', marginBottom: 8,
        }}>{project.id}</div>

        <h3 style={{
          fontFamily: "'Syne', sans-serif", fontSize: '1.3rem', fontWeight: 700,
          marginBottom: 10, letterSpacing: '-0.02em',
        }}>{project.title}</h3>

        <p style={{
          fontSize: '0.88rem', lineHeight: 1.7, color: 'rgba(226,240,255,0.6)', marginBottom: 16,
        }}>{project.description}</p>

        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6, marginBottom: 20 }}>
          {project.tags.map(tag => (
            <span key={tag} style={{
              fontFamily: "'DM Mono', monospace", fontSize: '0.65rem', padding: '3px 10px',
              border: `1px solid ${hovered ? 'rgba(0,212,255,0.4)' : 'rgba(0,212,255,0.2)'}`,
              color: hovered ? 'var(--neon)' : 'var(--muted)', letterSpacing: '0.06em',
              clipPath: 'polygon(4px 0%, 100% 0%, calc(100% - 4px) 100%, 0% 100%)',
              transition: 'all 0.2s',
            }}>{tag}</span>
          ))}
        </div>

        <div style={{ display: 'flex', gap: 10 }}>
          <a href={project.demo} style={{
            flex: 1, padding: '10px 14px', textAlign: 'center', textDecoration: 'none',
            fontFamily: "'DM Mono', monospace", fontSize: '0.72rem', letterSpacing: '0.06em',
            textTransform: 'uppercase', cursor: 'none', fontWeight: 500,
            background: 'linear-gradient(135deg, var(--neon), var(--neon2))', color: 'var(--bg)',
            clipPath: 'polygon(6px 0%, 100% 0%, calc(100% - 6px) 100%, 0% 100%)',
            transition: 'filter 0.3s',
          }}
            onMouseEnter={e => e.target.style.filter = 'brightness(1.15)'}
            onMouseLeave={e => e.target.style.filter = ''}
          >Live Demo</a>
          <a href={project.github} style={{
            flex: 1, padding: '9px 14px', textAlign: 'center', textDecoration: 'none',
            fontFamily: "'DM Mono', monospace", fontSize: '0.72rem', letterSpacing: '0.06em',
            textTransform: 'uppercase', cursor: 'none',
            background: 'transparent', color: 'var(--muted)',
            border: '1px solid rgba(255,255,255,0.1)',
            clipPath: 'polygon(6px 0%, 100% 0%, calc(100% - 6px) 100%, 0% 100%)',
            transition: 'all 0.3s',
          }}
            onMouseEnter={e => { e.target.style.borderColor = 'rgba(255,255,255,0.3)'; e.target.style.color = 'var(--text)'; }}
            onMouseLeave={e => { e.target.style.borderColor = 'rgba(255,255,255,0.1)'; e.target.style.color = 'var(--muted)'; }}
          >GitHub</a>
        </div>
      </div>
    </motion.div>
  )
}
