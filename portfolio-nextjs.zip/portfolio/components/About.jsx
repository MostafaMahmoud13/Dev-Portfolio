import { useRef } from 'react'
import { motion, useInView } from 'framer-motion'
import { siteData, skills } from '../data/portfolio'

const fadeUp = {
  hidden: { opacity: 0, y: 40 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.8, ease: [0.22, 1, 0.36, 1] } },
}

export default function About() {
  const ref = useRef(null)
  const inView = useInView(ref, { once: true, margin: '-100px' })

  return (
    <section id="about" ref={ref} style={{ padding: '120px 6%', position: 'relative', zIndex: 1 }}>
      <motion.div variants={fadeUp} initial="hidden" animate={inView ? 'visible' : 'hidden'} className="section-label">
        01 — About
      </motion.div>

      <motion.h2
        variants={fadeUp}
        initial="hidden"
        animate={inView ? 'visible' : 'hidden'}
        transition={{ delay: 0.1 }}
        style={{
          fontFamily: "'Syne', sans-serif", fontSize: 'clamp(2.5rem, 5vw, 4rem)',
          fontWeight: 800, letterSpacing: '-0.03em', lineHeight: 1, marginBottom: '3rem',
        }}
      >
        Crafting{' '}
        <span style={{
          background: 'linear-gradient(90deg, #00d4ff, #0066ff, #7b2fff)',
          WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', backgroundClip: 'text',
        }}>
          Digital Experiences
        </span>
        <br />That Convert
      </motion.h2>

      <div style={{
        display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 80,
        alignItems: 'start',
      }}
        className="about-grid"
      >
        <div>
          {siteData.bio.map((para, i) => (
            <motion.p
              key={i}
              variants={fadeUp}
              initial="hidden"
              animate={inView ? 'visible' : 'hidden'}
              transition={{ delay: 0.2 + i * 0.1 }}
              style={{
                fontSize: '1.05rem', lineHeight: 1.8,
                color: 'rgba(226,240,255,0.75)', marginBottom: '1.5rem',
              }}
              dangerouslySetInnerHTML={{
                __html: para.replace(/\*\*(.*?)\*\*/g, '<strong style="color:var(--neon);font-weight:500">$1</strong>'),
              }}
            />
          ))}
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
          {skills.map((skill, i) => (
            <SkillItem key={skill.name} skill={skill} delay={0.1 + i * 0.08} inView={inView} />
          ))}
        </div>
      </div>

      <style>{`
        @media(max-width:900px) { .about-grid { grid-template-columns: 1fr !important; gap: 40px !important; } }
        @media(max-width:500px) { .about-grid > div:last-child { grid-template-columns: 1fr !important; } }
      `}</style>
    </section>
  )
}

function SkillItem({ skill, delay, inView }) {
  return (
    <motion.div
      variants={{
        hidden: { opacity: 0, y: 20 },
        visible: { opacity: 1, y: 0, transition: { duration: 0.6, delay, ease: [0.22, 1, 0.36, 1] } },
      }}
      initial="hidden"
      animate={inView ? 'visible' : 'hidden'}
      whileHover={{ y: -2, borderColor: 'var(--neon)', boxShadow: '0 0 40px rgba(0,212,255,0.25)' }}
      style={{
        padding: '16px 20px', background: 'var(--surface)',
        border: '1px solid var(--border)', position: 'relative', overflow: 'hidden',
        clipPath: 'polygon(8px 0%, 100% 0%, calc(100% - 8px) 100%, 0% 100%)',
        transition: 'border-color 0.3s, box-shadow 0.3s',
      }}
    >
      <div style={{ fontFamily: "'DM Mono', monospace", fontSize: '0.78rem', color: 'var(--text)', letterSpacing: '0.05em', marginBottom: 4 }}>
        {skill.name}
      </div>
      <div style={{ height: 2, background: 'rgba(255,255,255,0.06)', borderRadius: 1, overflow: 'hidden' }}>
        <motion.div
          initial={{ width: 0 }}
          animate={inView ? { width: `${skill.level}%` } : { width: 0 }}
          transition={{ duration: 1.2, delay: delay + 0.3, ease: [0.22, 1, 0.36, 1] }}
          style={{
            height: '100%',
            background: 'linear-gradient(90deg, var(--neon), var(--neon2))',
            boxShadow: '0 0 8px rgba(0,212,255,0.6)',
          }}
        />
      </div>
      <div style={{ fontFamily: "'DM Mono', monospace", fontSize: '0.65rem', color: 'var(--muted)', textAlign: 'right', marginTop: 4 }}>
        {skill.level}%
      </div>
    </motion.div>
  )
}
