import { motion } from 'framer-motion'
import { siteData } from '../data/portfolio'

const containerVariants = {
  hidden: {},
  visible: { transition: { staggerChildren: 0.06, delayChildren: 0.8 } },
}
const charVariants = {
  hidden: { opacity: 0, y: '100%' },
  visible: { opacity: 1, y: 0, transition: { duration: 0.6, ease: [0.22, 1, 0.36, 1] } },
}

export default function Hero() {
  const chars = siteData.name.split('')

  return (
    <section
      id="hero"
      style={{
        minHeight: '100vh', display: 'flex', flexDirection: 'column',
        alignItems: 'center', justifyContent: 'center',
        textAlign: 'center', padding: '120px 6% 80px',
        position: 'relative', overflow: 'hidden',
      }}
    >
      {/* Grid overlay */}
      <div style={{
        position: 'absolute', inset: 0,
        backgroundImage: 'linear-gradient(rgba(0,212,255,0.04) 1px, transparent 1px), linear-gradient(90deg, rgba(0,212,255,0.04) 1px, transparent 1px)',
        backgroundSize: '60px 60px',
        maskImage: 'radial-gradient(ellipse 80% 80% at 50% 50%, black 40%, transparent 100%)',
        WebkitMaskImage: 'radial-gradient(ellipse 80% 80% at 50% 50%, black 40%, transparent 100%)',
      }} />

      {/* Status badge */}
      <motion.div
        initial={{ opacity: 0, y: 24 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3, duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
        style={{
          display: 'inline-flex', alignItems: 'center', gap: 8,
          fontFamily: "'DM Mono', monospace", fontSize: '0.72rem', letterSpacing: '0.12em',
          color: 'var(--neon)', textTransform: 'uppercase', marginBottom: '3rem',
          padding: '6px 16px', border: '1px solid rgba(0,212,255,0.25)',
          background: 'rgba(0,212,255,0.05)', position: 'relative', zIndex: 1,
        }}
      >
        <motion.span
          animate={{ opacity: [1, 0.3, 1] }}
          transition={{ duration: 2, repeat: Infinity }}
          style={{
            width: 6, height: 6, borderRadius: '50%',
            background: 'var(--neon)', boxShadow: '0 0 10px var(--neon)',
            display: 'inline-block',
          }}
        />
        Available for projects
      </motion.div>

      {/* Photo */}
      <motion.div
        initial={{ opacity: 0, scale: 0.8 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ delay: 0.5, duration: 1, ease: [0.22, 1, 0.36, 1] }}
        style={{
          position: 'relative', width: 180, height: 180,
          margin: '0 auto 2.5rem', zIndex: 1,
        }}
      >
        {/* Spinning ring */}
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ duration: 4, repeat: Infinity, ease: 'linear' }}
          style={{
            position: 'absolute', inset: -16, borderRadius: '50%',
            background: 'conic-gradient(from 0deg, transparent, #00d4ff, #0066ff, #7b2fff, transparent, #00d4ff, transparent)',
            filter: 'blur(1px)',
          }}
        />
        {/* Glow ring */}
        <motion.div
          animate={{ boxShadow: ['0 0 30px rgba(0,212,255,0.3), inset 0 0 30px rgba(0,212,255,0.1)', '0 0 60px rgba(0,212,255,0.6), inset 0 0 40px rgba(0,212,255,0.2)', '0 0 30px rgba(0,212,255,0.3), inset 0 0 30px rgba(0,212,255,0.1)'] }}
          transition={{ duration: 3, repeat: Infinity, ease: 'easeInOut' }}
          style={{
            position: 'absolute', inset: -8, borderRadius: '50%',
            border: '1px solid rgba(0,212,255,0.3)',
          }}
        />
        {/* Avatar */}
        <div style={{
          position: 'relative', zIndex: 2, width: 180, height: 180, borderRadius: '50%',
          background: 'linear-gradient(135deg, #0f1f3d, #0a1628)',
          border: '2px solid rgba(0,212,255,0.2)',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          fontSize: '5rem',
        }}>
          {/* Replace with: <img src="/images/photo.jpg" alt="Your Name" style={{width:'100%',height:'100%',objectFit:'cover',borderRadius:'50%'}} /> */}
          👨‍💻
        </div>
        {/* Badge */}
        <div style={{
          position: 'absolute', bottom: -4, right: -4, zIndex: 3,
          width: 40, height: 40, borderRadius: '50%',
          background: 'linear-gradient(135deg, var(--neon), var(--neon2))',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          fontSize: '1.1rem', boxShadow: '0 0 20px rgba(0,212,255,0.6)',
          border: '2px solid var(--bg)',
        }}>⚡</div>
      </motion.div>

      {/* Name - staggered chars */}
      <motion.h1
        variants={containerVariants}
        initial="hidden"
        animate="visible"
        style={{
          fontFamily: "'Syne', sans-serif",
          fontSize: 'clamp(3rem, 8vw, 7rem)',
          fontWeight: 800, letterSpacing: '-0.04em', lineHeight: 0.9,
          marginBottom: '1.2rem', zIndex: 1, overflow: 'hidden',
        }}
      >
        {chars.map((char, i) => (
          <motion.span
            key={i}
            variants={charVariants}
            style={{
              display: 'inline-block',
              ...(char === ' ' ? { width: '0.3em' } : {}),
              ...(i >= siteData.name.indexOf(' ') + 1 ? {
                background: 'linear-gradient(90deg, #00d4ff, #0066ff, #7b2fff)',
                WebkitBackgroundClip: 'text',
                WebkitTextFillColor: 'transparent',
                backgroundClip: 'text',
              } : {}),
            }}
          >
            {char === ' ' ? '\u00A0' : char}
          </motion.span>
        ))}
      </motion.h1>

      {/* Subtitle */}
      <motion.p
        initial={{ opacity: 0, y: 24 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 1.6, duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
        style={{
          fontFamily: "'DM Mono', monospace",
          fontSize: 'clamp(0.85rem, 2vw, 1.1rem)',
          color: 'var(--muted)', letterSpacing: '0.1em',
          marginBottom: '2.5rem', zIndex: 1,
        }}
      >
        <span style={{ color: 'var(--neon)' }}>// </span>
        Full-Stack Developer <span style={{ color: 'var(--neon)' }}>&amp;</span> Media Buyer
      </motion.p>

      {/* CTAs */}
      <motion.div
        initial={{ opacity: 0, y: 24 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 1.9, duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
        style={{ display: 'flex', gap: '1rem', justifyContent: 'center', flexWrap: 'wrap', zIndex: 1 }}
      >
        <a
          href="#projects"
          style={{
            padding: '14px 32px',
            background: 'linear-gradient(135deg, var(--neon), var(--neon2))',
            color: 'var(--bg)', fontFamily: "'DM Mono', monospace", fontSize: '0.8rem',
            letterSpacing: '0.08em', textTransform: 'uppercase', textDecoration: 'none',
            cursor: 'none', border: 'none', fontWeight: 500,
            clipPath: 'polygon(10px 0%, 100% 0%, calc(100% - 10px) 100%, 0% 100%)',
            transition: 'all 0.3s',
          }}
          onMouseEnter={e => { e.target.style.transform = 'translateY(-2px)'; e.target.style.boxShadow = '0 0 80px rgba(0,212,255,0.4)'; }}
          onMouseLeave={e => { e.target.style.transform = ''; e.target.style.boxShadow = ''; }}
        >
          View My Work
        </a>
        <a
          href="#contact"
          style={{
            padding: '13px 32px', background: 'transparent',
            color: 'var(--neon)', fontFamily: "'DM Mono', monospace", fontSize: '0.8rem',
            letterSpacing: '0.08em', textTransform: 'uppercase', textDecoration: 'none',
            cursor: 'none', border: '1px solid rgba(0,212,255,0.4)',
            clipPath: 'polygon(10px 0%, 100% 0%, calc(100% - 10px) 100%, 0% 100%)',
            transition: 'all 0.3s',
          }}
          onMouseEnter={e => { e.target.style.background = 'rgba(0,212,255,0.08)'; e.target.style.boxShadow = '0 0 40px rgba(0,212,255,0.25)'; }}
          onMouseLeave={e => { e.target.style.background = 'transparent'; e.target.style.boxShadow = ''; }}
        >
          Get In Touch
        </a>
      </motion.div>

      {/* Scroll indicator */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 2.2, duration: 0.8 }}
        style={{
          position: 'absolute', bottom: 40, left: '50%', transform: 'translateX(-50%)',
          display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8, zIndex: 1,
        }}
      >
        <span style={{ fontFamily: "'DM Mono', monospace", fontSize: '0.65rem', color: 'var(--muted)', letterSpacing: '0.15em', textTransform: 'uppercase' }}>Scroll</span>
        <motion.div
          animate={{ scaleY: [0, 1, 0] }}
          transition={{ duration: 2, repeat: Infinity, ease: 'easeInOut' }}
          style={{
            width: 1, height: 60,
            background: 'linear-gradient(to bottom, var(--neon), transparent)',
            transformOrigin: 'top',
          }}
        />
      </motion.div>
    </section>
  )
}
