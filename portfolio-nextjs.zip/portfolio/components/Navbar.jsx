import { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import Link from 'next/link'

const links = ['About', 'Projects', 'Stats', 'Contact']

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false)

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 50)
    window.addEventListener('scroll', handleScroll)
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  return (
    <motion.nav
      initial={{ y: -80, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
      style={{
        position: 'fixed', top: 0, left: 0, right: 0, zIndex: 100,
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        padding: scrolled ? '12px 6%' : '20px 6%',
        background: 'rgba(3,7,18,0.75)',
        backdropFilter: 'blur(20px)',
        borderBottom: '1px solid rgba(0,212,255,0.12)',
        transition: 'padding 0.3s',
      }}
    >
      <a href="#hero" style={{
        fontFamily: "'Syne', sans-serif", fontWeight: 800, fontSize: '1.2rem',
        color: 'var(--neon)', letterSpacing: '-0.02em', textDecoration: 'none',
      }}>
        &lt;<span style={{ color: 'var(--text)' }}>DEV</span>/&gt;
      </a>

      <ul style={{ display: 'flex', gap: '2rem', listStyle: 'none' }}>
        {links.map((link) => (
          <li key={link}>
            <a
              href={`#${link.toLowerCase()}`}
              style={{
                fontFamily: "'DM Mono', monospace", fontSize: '0.78rem',
                color: 'var(--muted)', textDecoration: 'none', letterSpacing: '0.08em',
                textTransform: 'uppercase', position: 'relative', transition: 'color 0.2s',
              }}
              onMouseEnter={e => e.target.style.color = 'var(--neon)'}
              onMouseLeave={e => e.target.style.color = 'var(--muted)'}
            >
              {link}
            </a>
          </li>
        ))}
      </ul>

      <a
        href="#contact"
        style={{
          fontFamily: "'DM Mono', monospace", fontSize: '0.78rem', padding: '8px 20px',
          border: '1px solid var(--neon)', color: 'var(--neon)', background: 'transparent',
          cursor: 'none', letterSpacing: '0.08em', textTransform: 'uppercase',
          transition: 'all 0.3s', textDecoration: 'none',
          clipPath: 'polygon(8px 0%, 100% 0%, calc(100% - 8px) 100%, 0% 100%)',
        }}
        onMouseEnter={e => {
          e.target.style.background = 'var(--neon)'
          e.target.style.color = 'var(--bg)'
          e.target.style.boxShadow = '0 0 40px rgba(0,212,255,0.25)'
        }}
        onMouseLeave={e => {
          e.target.style.background = 'transparent'
          e.target.style.color = 'var(--neon)'
          e.target.style.boxShadow = 'none'
        }}
      >
        Let's Talk
      </a>
    </motion.nav>
  )
}
