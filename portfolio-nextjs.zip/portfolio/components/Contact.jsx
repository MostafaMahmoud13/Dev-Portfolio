import { useRef, useState } from 'react'
import { motion, useInView } from 'framer-motion'
import { siteData } from '../data/portfolio'

const fadeUp = {
  hidden: { opacity: 0, y: 40 },
  visible: (d) => ({ opacity: 1, y: 0, transition: { duration: 0.8, delay: d, ease: [0.22, 1, 0.36, 1] } }),
}

const infoItems = [
  { icon: '📧', label: 'Email', value: siteData.email },
  { icon: '🐙', label: 'GitHub', value: siteData.github.replace('https://', '') },
  { icon: '💼', label: 'LinkedIn', value: siteData.linkedin.replace('https://', '') },
]

export default function Contact() {
  const ref = useRef(null)
  const inView = useInView(ref, { once: true, margin: '-80px' })
  const [form, setForm] = useState({ name: '', email: '', message: '' })
  const [toast, setToast] = useState(null)

  const handleSubmit = () => {
    if (!form.name || !form.email || !form.message) {
      setToast({ type: 'error', msg: '⚠ Please fill all fields.' })
    } else {
      setToast({ type: 'success', msg: '✓ Message sent successfully!' })
      setForm({ name: '', email: '', message: '' })
    }
    setTimeout(() => setToast(null), 3500)
  }

  return (
    <section id="contact" ref={ref} style={{ padding: '120px 6%', position: 'relative', zIndex: 1 }}>
      <motion.div variants={fadeUp} custom={0} initial="hidden" animate={inView ? 'visible' : 'hidden'} className="section-label">
        04 — Contact
      </motion.div>

      <motion.h2
        variants={fadeUp} custom={0.1} initial="hidden" animate={inView ? 'visible' : 'hidden'}
        style={{
          fontFamily: "'Syne', sans-serif", fontSize: 'clamp(2.5rem, 5vw, 4rem)',
          fontWeight: 800, letterSpacing: '-0.03em', lineHeight: 1, marginBottom: '3rem',
        }}
      >
        Let's Build<br />
        <span style={{
          background: 'linear-gradient(90deg, #00d4ff, #0066ff, #7b2fff)',
          WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', backgroundClip: 'text',
        }}>Something Great</span>
      </motion.h2>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1.5fr', gap: 80 }} className="contact-grid">
        {/* Info */}
        <div>
          <motion.p
            variants={fadeUp} custom={0.2} initial="hidden" animate={inView ? 'visible' : 'hidden'}
            style={{ fontSize: '1.05rem', lineHeight: 1.8, color: 'rgba(226,240,255,0.75)', marginBottom: '2rem' }}
          >
            Have a project in mind? Whether it's a full-stack app, a marketing campaign, or both — I'd love to hear about it.
          </motion.p>

          {infoItems.map((item, i) => (
            <motion.div
              key={item.label}
              variants={fadeUp} custom={0.2 + i * 0.1} initial="hidden" animate={inView ? 'visible' : 'hidden'}
              style={{
                display: 'flex', alignItems: 'center', gap: 16, marginBottom: 16, padding: 20,
                background: 'var(--surface)', border: '1px solid var(--border)',
                transition: 'border-color 0.3s, box-shadow 0.3s',
              }}
              whileHover={{ borderColor: 'rgba(0,212,255,0.3)', boxShadow: '0 0 40px rgba(0,212,255,0.25)' }}
            >
              <div style={{
                width: 44, height: 44, borderRadius: 2,
                background: 'linear-gradient(135deg, rgba(0,212,255,0.15), rgba(0,102,255,0.1))',
                border: '1px solid rgba(0,212,255,0.2)',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                fontSize: '1.1rem', flexShrink: 0,
              }}>{item.icon}</div>
              <div>
                <div style={{ fontFamily: "'DM Mono', monospace", fontSize: '0.68rem', color: 'var(--muted)', letterSpacing: '0.1em', textTransform: 'uppercase', marginBottom: 2 }}>{item.label}</div>
                <div style={{ fontSize: '0.9rem', color: 'var(--text)' }}>{item.value}</div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Form */}
        <motion.div
          variants={fadeUp} custom={0.2} initial="hidden" animate={inView ? 'visible' : 'hidden'}
          style={{ display: 'flex', flexDirection: 'column', gap: 16 }}
        >
          {[
            { id: 'name', label: 'Your Name', type: 'text', placeholder: 'John Doe' },
            { id: 'email', label: 'Email Address', type: 'email', placeholder: 'john@example.com' },
          ].map(field => (
            <div key={field.id}>
              <label style={{
                display: 'block', fontFamily: "'DM Mono', monospace", fontSize: '0.68rem',
                color: 'var(--muted)', letterSpacing: '0.1em', textTransform: 'uppercase', marginBottom: 8,
              }}>{field.label}</label>
              <input
                type={field.type}
                placeholder={field.placeholder}
                value={form[field.id]}
                onChange={e => setForm(p => ({ ...p, [field.id]: e.target.value }))}
                style={{
                  width: '100%', padding: '14px 16px',
                  background: 'var(--surface)', border: '1px solid var(--border)', color: 'var(--text)',
                  fontFamily: "'Cabinet Grotesk', sans-serif", fontSize: '0.95rem', outline: 'none',
                  clipPath: 'polygon(8px 0%, 100% 0%, calc(100% - 8px) 100%, 0% 100%)',
                  transition: 'border-color 0.3s',
                }}
                onFocus={e => { e.target.style.borderColor = 'var(--neon)'; e.target.style.background = 'rgba(0,212,255,0.03)'; }}
                onBlur={e => { e.target.style.borderColor = 'var(--border)'; e.target.style.background = 'var(--surface)'; }}
              />
            </div>
          ))}

          <div>
            <label style={{
              display: 'block', fontFamily: "'DM Mono', monospace", fontSize: '0.68rem',
              color: 'var(--muted)', letterSpacing: '0.1em', textTransform: 'uppercase', marginBottom: 8,
            }}>Message</label>
            <textarea
              placeholder="Tell me about your project..."
              value={form.message}
              onChange={e => setForm(p => ({ ...p, message: e.target.value }))}
              style={{
                width: '100%', padding: '14px 16px', height: 150,
                background: 'var(--surface)', border: '1px solid var(--border)', color: 'var(--text)',
                fontFamily: "'Cabinet Grotesk', sans-serif", fontSize: '0.95rem', outline: 'none',
                resize: 'none', clipPath: 'polygon(8px 0%, 100% 0%, calc(100% - 8px) 100%, 0% 100%)',
                transition: 'border-color 0.3s',
              }}
              onFocus={e => { e.target.style.borderColor = 'var(--neon)'; e.target.style.background = 'rgba(0,212,255,0.03)'; }}
              onBlur={e => { e.target.style.borderColor = 'var(--border)'; e.target.style.background = 'var(--surface)'; }}
            />
          </div>

          <motion.button
            onClick={handleSubmit}
            whileHover={{ y: -2, boxShadow: '0 0 80px rgba(0,212,255,0.4)' }}
            whileTap={{ scale: 0.98 }}
            style={{
              padding: '16px 40px', background: 'linear-gradient(135deg, var(--neon), var(--neon2))',
              color: 'var(--bg)', border: 'none',
              fontFamily: "'DM Mono', monospace", fontSize: '0.8rem', letterSpacing: '0.1em',
              textTransform: 'uppercase', cursor: 'none', fontWeight: 500,
              clipPath: 'polygon(10px 0%, 100% 0%, calc(100% - 10px) 100%, 0% 100%)',
              transition: 'all 0.3s', alignSelf: 'flex-start',
            }}
          >
            Send Message →
          </motion.button>
        </motion.div>
      </div>

      {/* Toast */}
      <motion.div
        initial={{ y: 80, opacity: 0 }}
        animate={toast ? { y: 0, opacity: 1 } : { y: 80, opacity: 0 }}
        transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
        style={{
          position: 'fixed', bottom: 30, right: 30, zIndex: 999,
          padding: '14px 24px', background: 'var(--surface)',
          border: `1px solid ${toast?.type === 'error' ? '#ff6b6b' : 'var(--neon)'}`,
          color: toast?.type === 'error' ? '#ff6b6b' : 'var(--neon)',
          fontFamily: "'DM Mono', monospace", fontSize: '0.78rem', letterSpacing: '0.06em',
          boxShadow: '0 0 40px rgba(0,212,255,0.25)',
          clipPath: 'polygon(8px 0%, 100% 0%, calc(100% - 8px) 100%, 0% 100%)',
        }}
      >
        {toast?.msg}
      </motion.div>

      <style>{`
        @media(max-width:900px) { .contact-grid { grid-template-columns: 1fr !important; gap: 40px !important; } }
      `}</style>
    </section>
  )
}
