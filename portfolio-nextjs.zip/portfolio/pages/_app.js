import '../styles/globals.css'
import dynamic from 'next/dynamic'

// Cursor is client-only
const Cursor = dynamic(() => import('../components/Cursor'), { ssr: false })
const ParticleBackground = dynamic(() => import('../components/ParticleBackground'), { ssr: false })

export default function App({ Component, pageProps }) {
  return (
    <>
      <Cursor />
      <ParticleBackground />
      <Component {...pageProps} />
    </>
  )
}
