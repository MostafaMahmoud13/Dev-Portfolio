import Head from 'next/head'
import Navbar from '../components/Navbar'
import Hero from '../components/Hero'
import About from '../components/About'
import Projects from '../components/Projects'
import Stats from '../components/Stats'
import Contact from '../components/Contact'
import Footer from '../components/Footer'
import { siteData } from '../data/portfolio'

export default function Home() {
  return (
    <>
      <Head>
        <title>{siteData.name} — Full-Stack Developer & Media Buyer</title>
        <meta name="description" content="Full-Stack Developer & Media Buyer — Building digital experiences that convert." />
        <meta property="og:title" content={`${siteData.name} — Full-Stack Developer & Media Buyer`} />
        <meta property="og:description" content="Full-Stack Developer & Media Buyer — Building digital experiences that convert." />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <link rel="icon" href="/favicon.ico" />
      </Head>

      <Navbar />
      <main>
        <Hero />
        <About />
        <Projects />
        <Stats />
        <Contact />
      </main>
      <Footer />
    </>
  )
}
