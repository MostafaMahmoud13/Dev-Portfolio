# 🚀 Developer Portfolio — Next.js + Framer Motion

An Awwwards-level developer portfolio built with **Next.js**, **Tailwind CSS**, and **Framer Motion**.

## ✨ Features
- Dark futuristic theme with neon blue accents
- Animated particle background with WebGL-style connections
- Custom cursor with smooth lag effect
- Hero section with staggered character animations + spinning glow ring
- Skills section with animated progress bars
- Project cards with 3D tilt + spotlight glow effect
- Animated stat counters
- Contact form with toast notifications
- Scroll-triggered reveal animations throughout
- Fully responsive

## 📁 Project Structure

```
portfolio/
├── components/
│   ├── Cursor.jsx           # Custom animated cursor
│   ├── ParticleBackground.jsx # Canvas particle system
│   ├── Navbar.jsx           # Sticky navigation
│   ├── Hero.jsx             # Full-screen hero section
│   ├── About.jsx            # About + skill bars
│   ├── Projects.jsx         # 3D tilt project cards
│   ├── Stats.jsx            # Animated counters
│   ├── Contact.jsx          # Contact form
│   └── Footer.jsx           # Footer with social links
├── data/
│   └── portfolio.js         # ⭐ YOUR DATA — Edit this file!
├── pages/
│   ├── _app.js
│   ├── _document.js
│   └── index.js
├── styles/
│   └── globals.css
├── public/
│   └── images/              # Add your photo here
├── package.json
├── tailwind.config.js
└── next.config.js
```

## 🛠️ Setup & Run Locally

### Prerequisites
- Node.js 18+ 
- npm or yarn

### Installation

```bash
# 1. Clone or download this project
cd portfolio

# 2. Install dependencies
npm install

# 3. Start development server
npm run dev

# 4. Open in browser
open http://localhost:3000
```

## 🎨 Customization

### Edit your info — `data/portfolio.js`

```js
export const siteData = {
  name: "Your Name",          // ← Your name
  role: "Full-Stack Developer & Media Buyer",
  email: "hello@yourname.dev", // ← Your email
  github: "https://github.com/yourname",
  linkedin: "https://linkedin.com/in/yourname",
  // ...
}
```

### Add your photo

1. Add your photo to `public/images/photo.jpg`
2. In `components/Hero.jsx`, replace:
   ```jsx
   👨‍💻
   ```
   with:
   ```jsx
   <img src="/images/photo.jpg" alt="Your Name" style={{width:'100%',height:'100%',objectFit:'cover',borderRadius:'50%'}} />
   ```

### Edit projects — `data/portfolio.js`

Update the `projects` array with your real projects, demo URLs, and GitHub links.

## 🚀 Deployment

### Deploy to Vercel (Recommended — FREE)

```bash
# 1. Install Vercel CLI
npm i -g vercel

# 2. Deploy
vercel

# Follow prompts — done! 🎉
```

Or connect your GitHub repo at [vercel.com](https://vercel.com) for automatic deploys.

### Deploy to GitHub Pages

```bash
# 1. In next.config.js, uncomment and set:
#    basePath: '/your-repo-name'
#    output: 'export'

# 2. Build static export
npm run build

# 3. The 'out' folder is your static site
# Push to gh-pages branch or use GitHub Actions
```

### GitHub Actions for auto-deploy to Pages

Create `.github/workflows/deploy.yml`:

```yaml
name: Deploy to GitHub Pages
on:
  push:
    branches: [main]
jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - uses: actions/setup-node@v3
        with: { node-version: 18 }
      - run: npm ci
      - run: npm run build
      - uses: peaceiris/actions-gh-pages@v3
        with:
          github_token: ${{ secrets.GITHUB_TOKEN }}
          publish_dir: ./out
```

## 📦 Tech Stack

| Technology | Purpose |
|---|---|
| Next.js 14 | React framework + routing |
| Tailwind CSS | Utility-first styling |
| Framer Motion | Animations + transitions |
| React Intersection Observer | Scroll-triggered effects |

## 🎯 Performance Tips

- Replace the emoji avatar with a WebP image (optimized, <100KB)
- Add `next/image` for project thumbnails
- Use Vercel Edge Network for global CDN
- Lighthouse score target: 95+ on all metrics

---

Built with ❤️ using Next.js + Framer Motion
