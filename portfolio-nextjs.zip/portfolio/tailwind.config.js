/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    './pages/**/*.{js,jsx}',
    './components/**/*.{js,jsx}',
  ],
  theme: {
    extend: {
      colors: {
        neon: '#00d4ff',
        neon2: '#0066ff',
        neon3: '#7b2fff',
        bg: '#030712',
        bg2: '#060e1f',
        surface: '#0a1628',
        surface2: '#0f1f3d',
        muted: '#4a6280',
      },
      fontFamily: {
        syne: ['Syne', 'sans-serif'],
        mono: ['DM Mono', 'monospace'],
        cabinet: ['Cabinet Grotesk', 'sans-serif'],
      },
    },
  },
  plugins: [],
}
